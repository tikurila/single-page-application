import React from 'react';

const FactsItem = () => {
	return (
		<div>
			
		</div>
	);
};

export default FactsItem;